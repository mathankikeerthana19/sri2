<?php
include ('database.php'); // Include the database configuration file

// Fetch data for Dashboard (Total Appointments, Total Feedback, etc.)
$totalAppointments = $conn->query("SELECT COUNT(*) as total FROM appointments")->fetch_assoc()['total'];
$totalFeedback = $conn->query("SELECT COUNT(*) as total FROM feedback")->fetch_assoc()['total'];

// Fetch approved appointments count
$approvedAppointments = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE status = 'approved'")->fetch_assoc()['total'];

// Fetch rejected appointments count
$rejectedAppointments = $conn->query("SELECT COUNT(*) as total FROM appointments WHERE status = 'rejected'")->fetch_assoc()['total'];

// Fetch Services
$servicesQuery = $conn->query("SELECT * FROM services");

// Fetch User Feedback
$feedbackQuery = $conn->query("SELECT * FROM feedback");

// Fetch User Appointments
$appointmentsQuery = $conn->query("SELECT * FROM appointments");

// Check if an action (like delete) is performed in service management
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    // Perform delete operation for services
    $service_id = $_GET['id'];
    $delete_sql = "DELETE FROM services WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $service_id);
    if ($stmt->execute()) {
        echo "<script>alert('Service deleted successfully'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Failed to delete service'); window.location='dashboard.php';</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Beauty Parlour</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        
        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 14px 20px;
            font-size: 18px;
            margin: 10px 0;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        /* Main Content Styling */
        .content {
            margin-left: 260px;
            padding: 20px;
            width: 100%;
        }

        /* Dashboard Cards */
        .card-container {
            display: flex;
            justify-content: space-between;
        }

        .card {
            background-color: #f1f1f1;
            padding: 20px;
            width: 20%;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h2 {
            font-size: 24px;
            margin: 0;
        }

        .card p {
            font-size: 18px;
            margin: 10px 0;
        }

        /* Table Styling */
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f4f4f4;
        }

        /* Action Buttons */
        .action-buttons a {
            padding: 5px 10px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin: 5px;
        }

        .action-buttons a.edit {
            background-color: #4CAF50;
        }

        .action-buttons a.delete {
            background-color: #f44336;
        }

        .action-buttons a:hover {
            opacity: 0.8;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="service_management.php">Service Management</a>
        <a href="user_feedback.php">User Feedback</a>
        <a href="user_appointments.php">User Appointments</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div id="dashboard" class="section">
            <h1>Dashboard</h1>
            <div class="card-container">
                <div class="card">
                    <h2><?php echo $totalAppointments; ?></h2>
                    <p>Total Appointments</p>
                </div>
                <div class="card">
                    <h2><?php echo $totalFeedback; ?></h2>
                    <p>Total Feedback</p>
                </div>
                <div class="card">
                    <h2><?php echo $approvedAppointments; ?></h2>
                    <p>Approved Appointments</p>
                </div>
                <div class="card">
                    <h2><?php echo $rejectedAppointments; ?></h2>
                    <p>Rejected Appointments</p>
                </div>
            </div>
        </div>
    </div>

   
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
