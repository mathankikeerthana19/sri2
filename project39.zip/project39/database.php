<?php
$servername = "localhost";  // Your MySQL server
$username = "root";  // Your MySQL username
$password = "";  // Your MySQL password (empty by default in XAMPP)
$dbname = "beauty_parlour";  // The database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
