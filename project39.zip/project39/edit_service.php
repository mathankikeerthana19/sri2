<?php
// Include the database connection
include('database.php');

// Initialize variables for the form
$service_id = $serviceName = $serviceDescription = $servicePrice = $serviceImage = '';

// Check if the 'id' is passed via URL
if (isset($_GET['id'])) {
    $service_id = $_GET['id'];

    // Fetch service details from the database
    $query = "SELECT * FROM services WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $service = $result->fetch_assoc();
        $serviceName = $service['name'];
        $serviceDescription = $service['description'];
        $servicePrice = $service['price'];
        $serviceImage = $service['image'];  // You might need this for displaying the current image
    } else {
        echo "<script>alert('Service not found!'); window.location='service_management.php';</script>";
        exit;
    }
}

// Handle the update of the service
if (isset($_POST['update_service'])) {
    $serviceName = $_POST['name'];
    $serviceDescription = $_POST['description'];
    $servicePrice = $_POST['price'];

    // Handle image update
    if ($_FILES['image']['name']) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        $serviceImage = $_FILES['image']['name'];  // Update image name
    }

    // Update service details in the database
    $update_sql = "UPDATE services SET name = ?, description = ?, price = ?, image = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssisi", $serviceName, $serviceDescription, $servicePrice, $serviceImage, $service_id);

    if ($stmt->execute()) {
        echo "<script>alert('Service updated successfully'); window.location='service_management.php';</script>";
    } else {
        echo "<script>alert('Failed to update service');</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }

        form {
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
        }

        form label {
            display: block;
            margin-bottom: 8px;
        }

        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
        }

        form button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }

        .image-preview {
            width: 700px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Edit Service</h1>
        <form action="edit_service.php?id=<?php echo $service_id; ?>" method="POST" enctype="multipart/form-data">
            <label for="name">Service Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $serviceName; ?>" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo $serviceDescription; ?></textarea><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" value="<?php echo $servicePrice; ?>" required><br>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image"><br>

            <h3>Current Image:</h3>
            <?php if ($serviceImage): ?>
                <img src="uploads/<?php echo $serviceImage; ?>" alt="Current Image" class="image-preview">
            <?php endif; ?>

            <button type="submit" name="update_service">Update Service</button>
        </form>
    </div>

</body>
</html>

<?php $conn->close(); ?>
