
<?php
// Database connection settings
$servername = "localhost";  // Database server
$username = "root";         // Database username
$password = "";             // Database password
$dbname = "beauty_parlour"; // Database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form input values
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Password entered by the user

    // Query to get admin user details from the database
    $sql = "SELECT * FROM admin_users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the admin user data
        $user = $result->fetch_assoc();
        // Verify the password using password_hash
        if (password_verify($password, $user['password'])) {
            // Start session and store user information
            session_start();
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            // Redirect to the admin dashboard or home page
            header("Location: adlogin.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "No such user found.";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Beauty Parlour Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .login-container {
            width: 300px;
            margin: 100px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .login-container h2 {
            text-align: center;
            color: #f78cc1;
        }
        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-container input[type="submit"] {
            background-color: #f78cc1;
            color: white;
            cursor: pointer;
            border: none;
        }
        .login-container input[type="submit"]:hover {
            background-color: #f56e96;
        }
        .error {
            color: red;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Admin Login</h2>
        <form action="adlogin.php" method="POST">
            <label for="username">Username</label><br>
            <input type="text" id="username" name="username" required><br>

            <label for="password">Password</label><br>
            <input type="password" id="password" name="password" required><br>

            <input type="submit" value="Login">
        </form>

        <?php
        // Display error if any
        if (isset($error)) {
            echo "<p class='error'>$error</p>";
        }
        ?>
    </div>

</body>
</html>
