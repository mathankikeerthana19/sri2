<?php
$servername = "localhost"; // Your MySQL server
$username = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$dbname = "beauty_parlour"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - Beauty Parlour</title>
    <style>
        body {
            font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                text-align: center;
                background-image: url("backimage1.jpeg");
                background-repeat: no-repeat;  
                background-size: cover;
                background-position: center;
                padding: 10px 0;
                width: 100%;
                height: 100%;
        }
    
        header {
                background-color: #ff69b4;;
                color: white;
                padding: 20px 0;
                text-align: center;
            }
            nav {
                overflow:hidden;
                display: flex;
                justify-content: center;
                align-items: center;
                gap:20px;
                background-color: black;
            }
            nav a {
                color: white;
                padding: 14px 20px;
                text-decoration: none;
                float:left;
                text-align: center;
            }
            nav a:hover {
                background-color: #ddd;
                color: black;
            }
    
        .services-section {
            margin: 20px 0;
            padding: 20px;
            flex-grow: 1;  /* Allow the section to take the remaining height */
        }
        .service-row {
            
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .service-column {
            width: 30%;
            background-color: white;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    
        .service-column img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            transition: transform 0.3s ease,box-shadow 0.3s ease;
            
        }
        .service-column img:hover{
            transform: translateY(-5px);
            box-shadow:0 6px 10px rgba(0, 0, 0, 0.15);  
        }
    
        .service-column h4 {
            margin: 10px 0;
        }
    
        .service-column p {
            color: #555;
        }
    
        .service-column .price {
            font-weight: bold;
            color: #f78cc1;
            font-size: 1.2em;
        }
        .service-section:hover{
            transform:scale(1.05);
        }
    
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Beauty Parlour Management System</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="about.html">About</a>
            <a href="service.php">Services</a>
            <a href="signup.php">Appointment</a>
            <a href="feedback.php">Feedback</a>
            <a href="admin.php">Admin</a>
        </nav>
    </header>

    <section class="services-section">
        <h2>Our Services</h2>
        <div class="service-row">
            <?php
            // Fetch services from the database
            $sql = "SELECT * FROM services";
            $result = $conn->query($sql);

            // Check if there are any results
            if ($result->num_rows > 0) {
                // Output data for each service
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="service-column">';
                    echo '<img src="' . $row['image'] . '" alt="' . $row['name'] . '">';
                    echo '<h4>' . $row['name'] . '</h4>';
                    echo '<p>' . $row['description'] . '</p>';
                    echo '<p class="price">' . $row['name'] . ' Starts From<br>$' . number_format($row['price'], 2) . '</p>';
                    echo '</div>';
                }
            } else {
                echo "No services available.";
            }

            // Close the database connection
            $conn->close();
            ?>
        </div>
    </section>

    <footer>
        <p>&copy; 2025 Beauty Parlour. All Rights Reserved.</p>
    </footer>
</body>
</html>


