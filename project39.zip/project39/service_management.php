<?php
include ('database.php'); // Include the database configuration file

// Fetch services
$servicesQuery = $conn->query("SELECT * FROM services");


if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    // Perform delete operation for services
    $service_id = $_GET['id'];
    $delete_sql = "DELETE FROM services WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $service_id);
    if ($stmt->execute()) {
        echo "<script>alert('Service deleted successfully'); window.location='service_management.php';</script>";
    } else {
        echo "<script>alert('Failed to delete service'); window.location='service_management.php';</script>";
    }
    $stmt->close();
}

// Check if form for adding new service is submitted
if (isset($_POST['add_service'])) {
    $serviceName = $_POST['name'];
    $serviceDescription = $_POST['description'];
    $servicePrice = $_POST['price'];
    $serviceImage = $_FILES['image']['name'];

    // Handle image upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    // Insert new service into the database
    $insert_sql = "INSERT INTO services (name, description, price, image) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("ssis", $serviceName, $serviceDescription, $servicePrice, $serviceImage);
    if ($stmt->execute()) {
        echo "<script>alert('Service added successfully'); window.location='service_management.php';</script>";
    } else {
        echo "<script>alert('Failed to add service');</script>";
    }
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            margin: 0;
            padding: 0;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #333;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            top: 0;
            left: 0;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        /* Main Content */
        .content {
            margin-left: 270px;
            padding: 20px;
            width: calc(100% - 270px);
        }

        h1 {
            color: #333;
        }

        /* Add Service Form */
        form {
            margin-top: 20px;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
            width: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin-bottom: 10px;
        }

        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
        }

        form button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        form button:hover {
            background-color: #45a049;
        }

        /* Table for displaying services */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        /* Action buttons */
        .action-buttons a {
    padding: 4px 8px;
    color: white;
    text-decoration: none;
    margin-right: 10px; /* Increased spacing between the buttons */
    border-radius: 3px;
    display: inline-block; /* Ensures buttons are not stacked */
}

        .action-buttons .edit {
            background-color: #4CAF50;
        }

        .action-buttons .delete {
            background-color: #f44336;
        }

        .action-buttons a:hover {
            opacity: 0.8;
        }

        /* Service Image Styling */
        .service-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

    <!-- Left Sidebar -->
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="service_management.php">Service Management</a>
        <a href="user_feedback.php">User Feedback</a>
        <a href="user_appointments.php">User Appointments</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1>Manage Services</h1>

        <!-- Add Service Form -->
        <h2>Add New Service</h2>
        <form action="service_management.php" method="POST" enctype="multipart/form-data">
            <label for="name">Service Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" required><br>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" required><br>

            <button type="submit" name="add_service">Add Service</button>
        </form>

        <!-- Current Services Table -->
        <h2>Current Services</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Service Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $servicesQuery->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td>$<?php echo number_format($row['price'], 2); ?></td>
                        <td>
                            <img src="uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>" class="service-image">
                        </td>
                        <td class="action-buttons">
                            <a href="edit_service.php?id=<?php echo $row['id']; ?>" class="edit">Edit</a>
                            <a href="service_management.php?action=delete&id=<?php echo $row['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this service?');">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>
</html>

<?php $conn->close(); ?>
