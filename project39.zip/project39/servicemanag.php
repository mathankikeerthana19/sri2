<?php
session_start();
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $service_name = $_POST['service_name'];
    $description = $_POST['description'];
    $cost = $_POST['cost'];
    $image = $_FILES['image']['name'];
    $image_temp = $_FILES['image']['tmp_name'];
    $upload_dir = "uploads/";

    // Upload the image
    move_uploaded_file($image_temp, $upload_dir . $image);

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "beauty_parlour";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert the new service into the database
    $sql = "INSERT INTO services (service_name, description, cost, image) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $service_name, $description, $cost, $image);
    if ($stmt->execute()) {
        echo "Service added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service - Admin Panel</title>
</head>
<body>
    <header>
        <h1>Add a New Service</h1>
    </header>
    
    <form action="add_service.php" method="POST" enctype="multipart/form-data">
        <label for="service_name">Service Name:</label><br>
        <input type="text" id="service_name" name="service_name" required><br><br>

        <label for="description">Description:</label><br>
        <textarea id="description" name="description" rows="4" required></textarea><br><br>

        <label for="cost">Cost:</label><br>
        <input type="text" id="cost" name="cost" required><br><br>

        <label for="image">Service Image:</label><br>
        <input type="file" id="image" name="image" accept="image/*" required><br><br>

        <input type="submit" value="Add Service">
    </form>
</body>
</html>
