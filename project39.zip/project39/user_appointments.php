<?php
include('database.php'); // Include the database configuration file

// Check if an action (approve/reject) is performed
if (isset($_GET['action']) && isset($_GET['id'])) {
    $appointment_id = $_GET['id'];
    $action = $_GET['action'];

    // Initialize query variable
    $update_sql = "";

    // Determine the action (approve or reject)
    if ($action == 'approve') {
        $update_sql = "UPDATE appointments SET status = 'approved' WHERE id = ?";
    } else if ($action == 'reject') {
        $update_sql = "UPDATE appointments SET status = 'rejected' WHERE id = ?";
    }

    // Check if the query is set and proceed
    if ($update_sql != "") {
        // Prepare the SQL statement
        $stmt = $conn->prepare($update_sql);
        
        // Check if the statement was prepared successfully
        if ($stmt === false) {
            die('Error preparing SQL: ' . $conn->error);
        }

        // Bind the parameter (appointment ID)
        $stmt->bind_param("i", $appointment_id);

        // Execute the query and check if it was successful
        if ($stmt->execute()) {
            echo "<script>alert('Appointment $action successfully'); window.location='user_appointments.php';</script>";
        } else {
            echo "<script>alert('Failed to update appointment status'); window.location='user_appointments.php';</script>";
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // If the query is empty, throw an error (unexpected action)
        echo "<script>alert('Invalid action specified'); window.location='user_appointments.php';</script>";
    }
}

// Fetch all appointments
$appointmentsQuery = $conn->query("SELECT * FROM appointments");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Appointments</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .content {
            margin-left: 260px;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
        }

        /* Button styles */
        .approve-btn, .reject-btn {
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            text-align: center;
            display: inline-block;
            width: 60%;
        }

        .approve-btn {
            background-color: #4CAF50;
            color: white;
        }

        .approve-btn:hover {
            background-color: #45a049;
        }

        .reject-btn {
            background-color: #f44336;
            color: white;
        }

        .reject-btn:hover {
            background-color: #d32f2f;
        }

        .action-buttons a {
            display: block;
            margin-bottom: 10px;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #333;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            top: 0;
            left: 0;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="service_management.php">Service Management</a>
        <a href="user_feedback.php">User Feedback</a>
        <a href="user_appointments.php">User Appointments</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1>User Appointments</h1>
        
        <!-- Appointments Table -->
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Service</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Special Request</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($appointment = $appointmentsQuery->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $appointment['name']; ?></td>
                        <td><?php echo $appointment['phone']; ?></td>
                        <td><?php echo $appointment['service']; ?></td>
                        <td><?php echo $appointment['date']; ?></td>
                        <td><?php echo $appointment['time']; ?></td>
                        <td><?php echo $appointment['specialRequest']; ?></td>
                        <td><?php echo ucfirst($appointment['status']); ?></td>
                        <td class="action-buttons">
                            <!-- Approve / Reject Buttons -->
                            <a href="user_appointments.php?action=approve&id=<?php echo $appointment['id']; ?>" 
                               class="approve-btn" 
                               onclick="return confirm('Are you sure you want to approve this appointment?');">
                               Approve
                            </a>
                            <a href="user_appointments.php?action=reject&id=<?php echo $appointment['id']; ?>" 
                               class="reject-btn" 
                               onclick="return confirm('Are you sure you want to reject this appointment?');">
                               Reject
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>
</html>

<?php $conn->close(); ?>
