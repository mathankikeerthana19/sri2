<?php
include('database.php'); // Include the database configuration file

// Fetch user feedback
$feedbackQuery = $conn->query("SELECT * FROM feedback");

// Check if a delete action is triggered
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    // Perform delete operation for feedback
    $feedback_id = $_GET['id'];
    $delete_sql = "DELETE FROM feedback WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $feedback_id);
    if ($stmt->execute()) {
        echo "<script>alert('Feedback deleted successfully'); window.location='user_feedback.php';</script>";
    } else {
        echo "<script>alert('Failed to delete feedback'); window.location='user_feedback.php';</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            padding-top: 20px;
            position: fixed;
            height: 100%;
            top: 0;
            left: 0;
        }

        .sidebar a {
            color: white;
            padding: 15px;
            text-decoration: none;
            display: block;
            text-align: left;
            font-size: 18px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .content {
            margin-left: 270px;
            padding: 20px;
            width: 100%;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        /* Delete Button Styling */
        .delete-btn {
            background-color: #f44336;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            text-decoration: none;
        }

        .delete-btn:hover {
            background-color: #d32f2f;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

    <!-- Left Sidebar -->
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="service_management.php">Service Management</a>
        <a href="user_feedback.php">User Feedback</a>
        <a href="user_appointments.php">User Appointments</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1>User Feedback</h1>
        
        <!-- Feedback Table -->
        <table>
            <thead>
                <tr>
                    <th>User</th>
                    <th>Email</th>
                    <th>Service</th>
                    <th>Feedback</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($feedback = $feedbackQuery->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $feedback['name']; ?></td>
                        <td><?php echo $feedback['email']; ?></td>
                        <td><?php echo $feedback['service']; ?></td>
                        <td><?php echo $feedback['message']; ?></td>
                        <td>
                            <!-- Delete Button with Confirmation -->
                            <a href="user_feedback.php?action=delete&id=<?php echo $feedback['id']; ?>" 
                               class="delete-btn" 
                               onclick="return confirm('Are you sure you want to delete this feedback?');">
                               Delete
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
